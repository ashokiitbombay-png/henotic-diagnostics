import React from 'react';

interface ProductSchemaProps {
  serviceName: string;
  serviceSlug: string;
  price?: number;
  marketPrice?: number;
  category?: string;
  prerequisites?: string;
  fastingGuidelines?: string;
  reportingTime?: string;
  bookingProcess?: string;
}

/**
 * 🛒 Product + Offer + MedicalTest + AggregateRating Schema Markup (Server Component)
 * Generates Product JSON-LD compliant with Google Merchant Center & AI Engine Guidelines.
 * Includes: AggregateRating, MerchantReturnPolicy, OfferShippingDetails, Clinical Prerequisites
 */
export default function ProductSchema({
  serviceName,
  serviceSlug,
  price,
  marketPrice,
  category,
  prerequisites,
  fastingGuidelines,
  reportingTime,
  bookingProcess,
}: ProductSchemaProps) {
  const baseUrl = 'https://www.henoticdiagnostics.com';
  const url = `${baseUrl}/services/${serviceSlug}`;

  const schema: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: serviceName,
    description: `${serviceName} by Henotic Diagnostics — NABL & ISO accredited diagnostic service in Navi Mumbai. Same-day reporting available.`,
    brand: {
      '@type': 'Brand',
      name: 'Henotic Diagnostics',
    },
    ...(category && { category }),

    // Medical Procedure / Test Details for Healthcare AI & Search Crawlers
    subjectOf: {
      '@type': 'MedicalTest',
      name: serviceName,
      code: {
        '@type': 'MedicalCode',
        code: serviceSlug,
        codingSystem: 'HenoticDiagnosticCatalog',
      },
      ...(reportingTime && { normalRange: reportingTime }),
    },


    // Offer with eligible region
    offers: {
      '@type': 'Offer',
      url,
      priceCurrency: 'INR',
      price: price != null ? price.toString() : '1500',
      ...(marketPrice != null && price != null && {
        priceSpecification: {
          '@type': 'UnitPriceSpecification',
          price: price.toString(),
          priceCurrency: 'INR',
          referenceQuantity: {
            '@type': 'QuantitativeValue',
            value: '1',
          },
        },
      }),
      availability: 'https://schema.org/InStock',
      seller: {
        '@type': 'Organization',
        name: 'Henotic Diagnostics',
      },
      eligibleRegion: {
        '@type': 'Country',
        name: 'IN',
      },
      // Shipping details — free digital report delivery
      shippingDetails: {
        '@type': 'OfferShippingDetails',
        shippingRate: {
          '@type': 'MonetaryAmount',
          value: '0',
          currency: 'INR',
        },
        shippingDestination: {
          '@type': 'DefinedRegion',
          addressCountry: 'IN',
        },
        deliveryTime: {
          '@type': 'ShippingDeliveryTime',
          handlingTime: {
            '@type': 'QuantitativeValue',
            minValue: '0',
            maxValue: '0',
            unitCode: 'DAY',
          },
          transitTime: {
            '@type': 'QuantitativeValue',
            minValue: '0',
            maxValue: '1',
            unitCode: 'DAY',
          },
        },
      },
      // Return/Refund policy
      hasMerchantReturnPolicy: {
        '@type': 'MerchantReturnPolicy',
        applicableCountry: 'IN',
        returnPolicyCategory: 'https://schema.org/MerchantReturnNotPermitted',
        merchantReturnDays: '0',
        returnMethod: 'https://schema.org/ReturnByMail',
        returnFees: 'https://schema.org/FreeReturn',
        refundType: 'https://schema.org/FullRefund',
        url: `${baseUrl}/refund-returns`,
      },
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}
